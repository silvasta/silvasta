"""
Prepare for boot

- search for config file, until found
- check project meta
"""

from collections.abc import Callable
from dataclasses import asdict, dataclass
from importlib.metadata import PackageNotFoundError, version
from pathlib import Path
from typing import Self

from loguru import logger

from sstcore.utils.log import LogParam

from ..utils.path import HomeSetup, pyproject_name
from .settings import SstSettings


@dataclass
class BootResult:
    """Final confirmed Result by ConfigBootstrap"""

    project_name: str
    project_version: str
    setting_file: Path


@dataclass
class BootDefaults:
    """Input Args for ConfigBootstrap"""

    home_setup: HomeSetup
    project_name: str = ""
    project_root: Path | None = None
    project_version: str = "0.0.0"

    # IDEA: logfile/param?

    setting_file: Path | None = None
    setting_file_name: str = "settings.json"


class ConfigBootstrap[TSettings: SstSettings]:
    """Collection of methods that run before config is ready"""

    @classmethod
    def initial_setup(
        cls, settings_cls: type[TSettings], defaults: BootDefaults
    ) -> BootResult:

        project_name: str = cls.check_project_name(defaults)
        version: str = cls.check_project_version(
            package_name=project_name, defaults=defaults
        )
        HomeSetup(defaults.home_setup).boot(
            project_name=project_name,
            project_root=defaults.project_root,
            local_root=defaults.project_root,
        )
        for path in DefaultBootPaths.path_factory(defaults):
            if final_setting_file := cls.check_location(path, settings_cls):
                logger.debug(f"Found valid Settings: {final_setting_file=}")
                break
        else:
            log_setup = LogParam(log_dir=defaults.home_setup.log_dir)
            final_setting_file: Path = cls.scaffold_default_config(
                settings_cls, defaults, log_setup.attach_logname(project_name)
            )
            logger.warning(
                f"No Settings found — created scaffold: {final_setting_file=}"
            )

        return BootResult(
            project_name=defaults.project_name,
            project_version=version,
            setting_file=final_setting_file,
        )

    @staticmethod
    def check_location(
        path_function: Callable, settings_cls: type[TSettings]
    ) -> Path | None:
        """Verify if SettingsFile exists at path and can be loaded"""

        path = None  # Failsafe for logs in except
        try:
            path: Path = path_function()
            if not path.exists():
                raise FileNotFoundError
            settings_cls.load(path)
            logger.debug(f"Found valid SettingsFile at {path=}")
            return path

        except (FileNotFoundError, AttributeError) as error:
            logger.debug(f"No file found at location: {error=}")

        except ValueError as error:
            logger.warning(f"Problem with Settings: {path=}, {error=}")

        return None

    @classmethod
    def scaffold_default_config(
        cls, settings_cls, defaults: BootDefaults, log_setup: LogParam
    ) -> Path:
        """Create a minimal valid config. Never overwrite existing."""
        path = None  # Failsafe for logs in except
        for path_function in DefaultBootPaths.path_factory(defaults):
            try:
                if (path := path_function()).exists():
                    raise FileExistsError(f"Detected Existing File! {path=}")
                path.parent.mkdir(parents=True, exist_ok=True)

                settings_cls(log=log_setup).save(path)

                logger.info("New setting file created from defaults")
                return path

            except (FileNotFoundError, AttributeError) as error:
                logger.debug(f"Path can't be constructed: {error=}")

            except ValueError as error:
                logger.warning(f"Problem with: {path=}, {error=}")

        raise RuntimeError("Unable to scaffold new setting file")

    @staticmethod
    def check_project_name(defaults: BootDefaults) -> str:
        """Get project_version from installation with project_name"""

        if not (provided_name := defaults.project_name):
            logger.debug("no project name provided")

        try:
            pyproject_toml_name: str = pyproject_name()

        except FileNotFoundError:
            if defaults.home_setup == HomeSetup.PROJECT:
                logger.warning("Unable to find pyproject.toml file")
            else:
                logger.debug("no project name found in pyproject.toml")
            pyproject_toml_name: str = ""

        if provided_name != pyproject_toml_name:
            msg = f"Using {provided_name=} but {pyproject_toml_name=}"
            logger.info(msg)

        name: str = provided_name or pyproject_toml_name or ""

        logger.debug(f"finally using for project: {name=}")
        return name

    @staticmethod
    def check_project_version(
        package_name: str, defaults: BootDefaults
    ) -> str:
        """Get project_version from installation with project_name"""

        try:
            project_version: str = version(package_name)
            return project_version
        except PackageNotFoundError:
            logger.warning(
                f"Package '{package_name}' not installed in this environment. "
                "Are you running in dev mode without 'uv tool install -e .'?"
            )
        except ValueError:
            logger.warning("No distribution name provided to check version")

        return defaults.project_version


class DefaultBootPaths(BootDefaults):
    """Helper for Lazy Path loading, holds Sorting of Path execution"""

    def provided_setting_file(self) -> Path:
        if self.setting_file:
            return self.setting_file
        raise FileNotFoundError("No setting file provided in BootDefaults")

    def provided_from_home_setup(self) -> Path:
        return self.home_setup.configs_dir / self.setting_file_name

    def _home_setup_path(self, target: HomeSetup):
        if self.home_setup == target:
            raise AttributeError("This path is 'provided_from_home_setup'")
        return target.configs_dir / self.setting_file_name

    def home_setup_project(self) -> Path:
        return self._home_setup_path(target=HomeSetup.PROJECT)

    def home_setup_global(self) -> Path:
        return self._home_setup_path(target=HomeSetup.GLOBAL)

    def home_setup_local(self) -> Path:
        return self._home_setup_path(target=HomeSetup.LOCAL)

    @classmethod
    def path_factory(cls, defaults: BootDefaults) -> list[Callable[..., Path]]:
        factory: Self = cls(**asdict(defaults))
        return [
            factory.provided_setting_file,
            factory.provided_from_home_setup,
            factory.home_setup_project,
            factory.home_setup_global,
            factory.home_setup_local,
        ]
